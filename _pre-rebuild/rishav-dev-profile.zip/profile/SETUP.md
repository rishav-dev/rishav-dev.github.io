# Publishing this profile README

These files belong in the repo named after your username: **`rishav-dev/rishav-dev`**.
GitHub renders that repo's README on your profile page. It is not the same repo
as your website.

```
README.md
assets/banner.png
assets/stats.png
```

That repo is probably not cloned on your machine yet:

```powershell
cd C:\Users\Rishav\Documents\GitHub
git clone https://github.com/rishav-dev/rishav-dev.git
```

Copy the three files above from this folder into the clone, overwriting what is
there. Any old `assets/banner.svg` can be deleted; nothing references it any
more.

```powershell
cd rishav-dev
git add -A
git commit -m "Rebuild profile: repo-backed projects only, new stats strip"
git push origin main
```

Refresh github.com/rishav-dev and it is live.

## What is in it

- **Banner and stats strip** rendered from the same fonts and palette as the
  site, so the profile and rishavchakravarty.com read as one thing. Both are
  PNGs committed to the repo rather than calls to a card service, because those
  services spend a good part of the day rate-limited and a rate-limited card
  shows up on your profile as a broken image.
- **Four project cards, four public repositories**, laid out two by two. Same
  four as the site: the Reddit study, the campus safety corpus, the Billboard
  piece and the Nim agent.
- **The coursework section is gone.** Anything that cannot be opened on GitHub
  is not on the page.
- **StressMap is gone.** It is a fork of the UMassCDS repo with a single commit,
  so it does not hold up as portfolio work next to the other four.
- **Two collapsible sections** so the classifier table and the two supporting
  repos are there for anyone who wants them, without crowding the top of the
  page.
- **The pitch table is correct.** Karnah $750 at UPitch, CalendAI $500 from the
  Apex Center, Trendify AI $300 at the Minute Pitch. Kinjal is credited on all
  three, because you won all three together.
- **No dynamic third-party images at all now.** Nothing on the page can break on
  someone else's rate limit.
- **No em dashes**, and the same first-person voice as the site.

## Regenerating the images

Both PNGs are rendered by scripts in the website repo:

```powershell
node tools/make-banner.mjs
node tools/make-stats.mjs
```

Edit `tools/banner-template.html` or `tools/stats-template.html` to change the
text, rerun, then copy the output back into this folder. If a number on the
stats strip changes, change it there and in `src/data/profile.ts` so the site
and the profile never disagree.
